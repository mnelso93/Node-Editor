﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

public class NodeA : NodeBaseClass {


    public NodeA (Rect r, int ID) : base(r,ID)
    {
        
    }

    public override void DrawGUI(int winID)
    {
        if(GUILayout.Button("Edit"))
        {
			EditorWindow.GetWindow<StitchEditor> ();
        }
        BaseDraw();
    }

    public override void AttachComplete(NodeBaseClass winID)
    {
        base.linkedNodes.Add(winID);
    }
}
