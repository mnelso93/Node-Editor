﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

public class NodeExample : EditorWindow
{

    public List<NodeBaseClass> myNodes = new List<NodeBaseClass>();

    public Spool spoolToLoad;
    public int nodeAttachID = -1;
	string stitchName;
	string newStitchName;
	public List<Stitch> stitchList = new List<Stitch> ();
    [MenuItem("Node Editor/ Editor")]
    public static void showWindow()
    {
        GetWindow<NodeExample>();
    }

    public void OnGUI()
    {
		EditorGUILayout.LabelField ("Node Editor", EditorStyles.boldLabel);
        spoolToLoad = (Spool)EditorGUILayout.ObjectField(spoolToLoad, typeof(Spool), true);

		stitchName = EditorGUILayout.TextField ("Name", stitchName);
		newStitchName = EditorGUILayout.TextField ("New Stitch Name", newStitchName);

		if (spoolToLoad == null) 
		{

			if (GUILayout.Button ("New Spool")) 
			{
				if (stitchName != "" && stitchName != " ") 
				{
					Spool newSpool = ScriptableObject.CreateInstance<Spool> ();
					newSpool.storyName = stitchName;
					newSpool.stitchCollection = new Stitch[1];
					newSpool.startStitch = newSpool.stitchCollection [0];
					AssetDatabase.CreateAsset (newSpool, "Assets/" + newSpool.storyName.Replace (" ", "_") + ".asset");
					AssetDatabase.SaveAssets ();
					stitchName = "";
				}
				else
					EditorGUILayout.HelpBox ("Name cannot be empty", MessageType.Error);
			} 

		}

        if (spoolToLoad != null)
        {

            for (int i = 0; i < myNodes.Count; i++)
            {
                for (int j = 0; j < myNodes[i].linkedNodes.Count; j++)
                {
                    DrawNodeCurve(myNodes[i].rect, myNodes[i].linkedNodes[j].rect);
                }
            }
            if (GUILayout.Button("Add Stitch"))
            {
				if (newStitchName != "" && newStitchName != " ") {
					myNodes.Add (new NodeA (new Rect (10, 40, 100, 100), myNodes.Count));
					foreach (Stitch stitch in spoolToLoad.stitchCollection) {
						stitchList.Add (stitch);
					}
					Stitch newStitch = ScriptableObject.CreateInstance<Stitch> ();
					newStitch.stitchID = -1;
					newStitch.stitchName = newStitchName;
					newStitch.summary = "";
					newStitch.background = null;
					newStitch.performers = new Performer[1];
					newStitch.dialogs = new Dialog[1];
					newStitch.yarns = new Yarn[1];
					newStitch.status = Stitch.stitchStatus.regular;
					AssetDatabase.CreateAsset (newStitch, "Assets/" + newStitch.stitchName.Replace (" ", "_") + ".asset");
					AssetDatabase.SaveAssets ();
					stitchList.Add (newStitch);
					spoolToLoad.stitchCollection = stitchList.ToArray ();
					myNodes [myNodes.Count - 1].closeFunction += RemoveNode;
					myNodes [myNodes.Count - 1].nodeEditor = this;
					newStitchName = "";
				} else
					EditorGUILayout.HelpBox ("stitch name cannot be empty.", MessageType.Error);
            }

			if (GUILayout.Button ("Save Spool")) 
			{
				if (stitchName != "" && stitchName != " ") 
				{
					string path = AssetDatabase.GetAssetPath (spoolToLoad);
					Spool updateSpool = AssetDatabase.LoadAssetAtPath (path, typeof(Spool)) as Spool;
					updateSpool.storyName = stitchName;
					updateSpool.startStitch = spoolToLoad.startStitch;
					updateSpool.stitchCollection = spoolToLoad.stitchCollection;
					AssetDatabase.SaveAssets ();
				}
				else
					EditorGUILayout.HelpBox ("Name cannot be empty", MessageType.Error);
			} 

            BeginWindows();
            for (int i = 0; i < myNodes.Count; i++)
            {
                myNodes[i].rect = GUI.Window(i, myNodes[i].rect, myNodes[i].DrawGUI, "Stitch " + (i + 1));
            }
            EndWindows();

            for (int i = 0; i < myNodes.Count; i++)
            {
                if (GUI.Button(new Rect(myNodes[i].rect.xMax - 10, myNodes[i].rect.y + myNodes[i].rect.height / 2, 20, 20), "+"))
                {
                    BeginAttachment(i);
                }

                if (GUI.Button(new Rect(myNodes[i].rect.xMin - 10, myNodes[i].rect.y + myNodes[i].rect.height / 2, 20, 20), "O"))
                {
                    EndAttachment(i);
                }
            }
        }
    }

    public void RemoveNode(int id)
    {
        for (int i = 0; i < myNodes.Count; i++)
        {
            myNodes[i].linkedNodes.RemoveAll(item => item.id == id);
        }
        myNodes.RemoveAt(id);
        UpdateNodeIDs();
    }

    public void UpdateNodeIDs()
    {
        for (int i = 0; i < myNodes.Count; i++)
        {
            myNodes[i].ReassignID(i);
        }
    }

    public void BeginAttachment(int winID)
    {
        nodeAttachID = winID;
    }

    public void EndAttachment(int winID)
    {
        if (nodeAttachID > -1)
        {
            myNodes[nodeAttachID].AttachComplete(myNodes[winID]);
        }
        nodeAttachID = -1;
    }

    void DrawNodeCurve(Rect start, Rect end)
    {
        Vector3 startPos = new Vector3(start.x + start.width, start.y + (start.height / 2) + 10, 0);
        Vector3 endPos = new Vector3(end.x, end.y + (end.height / 2) + 10, 0);
        Vector3 startTan = startPos + Vector3.right * 100;
        Vector3 endTan = endPos + Vector3.left * 100;
        Color shadowCol = new Color(0, 0, 0, 0.06f);


        Handles.DrawBezier(startPos, endPos, startTan, endTan, Color.black, null, 5);
    }

}
