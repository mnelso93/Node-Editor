﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

public class StitchEditor : EditorWindow 
{
	Spool storyToEdit;
	Stitch stitchToEdit;
	Vector2 scrollPosition = new Vector2(Screen.width, Screen.height);
	bool isStart;
	List <Stitch> stitchList = new List<Stitch>();


	public void OnGUI()
	{
		EditorGUILayout.LabelField ("Spool and Stitch", EditorStyles.boldLabel);
		storyToEdit = (Spool)EditorGUILayout.ObjectField ("Spool to Edit", storyToEdit, typeof(Spool), true);
		stitchToEdit = (Stitch)EditorGUILayout.ObjectField ("Stitch to Edit", stitchToEdit, typeof(Stitch), true);

		if (storyToEdit != null) 
		{
			foreach(Stitch stitch in storyToEdit.stitchCollection)
			{
				stitchList.Add (stitch);
			}

			if (stitchList.Contains (stitchToEdit)) 
			{
				if (stitchToEdit == storyToEdit.startStitch) {
					isStart = true;
				} else
					isStart = false;
				
				EditorGUILayout.Space ();
				EditorGUILayout.LabelField ("Stitch Info", EditorStyles.boldLabel);

				scrollPosition = EditorGUILayout.BeginScrollView (scrollPosition);
				stitchToEdit.stitchName = EditorGUILayout.TextField ("Stitch Name", stitchToEdit.stitchName);
				stitchToEdit.stitchID = EditorGUILayout.IntField ("Stitch ID", stitchToEdit.stitchID);
				stitchToEdit.summary = EditorGUILayout.TextField ("Stitch Summary", stitchToEdit.summary);
				stitchToEdit.status = (Stitch.stitchStatus)EditorGUILayout.EnumPopup ("Stitch Type", stitchToEdit.status);
				stitchToEdit.background = (Sprite)EditorGUILayout.ObjectField ("Background", stitchToEdit.background, typeof(Sprite), true);
				isStart = EditorGUILayout.Toggle ("Is Start Stitch", isStart);

				if (isStart)
					storyToEdit.startStitch = stitchToEdit;
				else if (stitchToEdit != storyToEdit.startStitch)
					isStart = false;
				
				SerializedObject stitch = new SerializedObject (stitchToEdit);

				stitch.Update ();
				SerializedProperty Performers = stitch.FindProperty ("performers");
				EditorGUILayout.PropertyField (Performers, true);

				SerializedProperty Dialogs = stitch.FindProperty ("dialogs");
				EditorGUILayout.PropertyField (Dialogs, true);

				SerializedProperty Yarns = stitch.FindProperty ("yarns");
				EditorGUILayout.PropertyField (Yarns, true);
				stitch.ApplyModifiedProperties ();
				EditorGUILayout.EndScrollView ();

				if(GUILayout.Button("Save Stitch"))
				{
					string path = AssetDatabase.GetAssetPath (stitchToEdit);
					Stitch updateStitch = AssetDatabase.LoadAssetAtPath (path, typeof(Stitch)) as Stitch;
					updateStitch.stitchName = stitchToEdit.stitchName;
					updateStitch.stitchID = stitchToEdit.stitchID;
					updateStitch.summary = stitchToEdit.summary;
					updateStitch.status = stitchToEdit.status;
					updateStitch.background = stitchToEdit.background;
					updateStitch.performers = stitchToEdit.performers;
					updateStitch.dialogs = stitchToEdit.dialogs;
					updateStitch.yarns = stitchToEdit.yarns;
					AssetDatabase.SaveAssets ();

					string storyPath = AssetDatabase.GetAssetPath (storyToEdit);
					Spool updateSpool = AssetDatabase.LoadAssetAtPath (storyPath, typeof(Spool)) as Spool;
					updateSpool.startStitch = storyToEdit.startStitch;
					AssetDatabase.SaveAssets ();
				}
			}
		}
	}
}
